<div class="error">
	<p><?php _e( 'The <strong>WooCommerce</strong> is not installed and/or activated. Please install and/or activate before you can using <strong>TP Hotel Booking WooCommerce</strong> add-on', 'tp-hotel-booking-woocommerce' );?></p>
</div>